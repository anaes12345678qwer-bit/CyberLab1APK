package com.cyberlab.app;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.widget.*; import java.security.SecureRandom;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(28,36,28,28); l.setBackgroundColor(Color.rgb(8,8,8));
 TextView t=new TextView(this); t.setText("🛡️ Cyber Lab"); t.setTextSize(28); t.setTextColor(Color.WHITE); l.addView(t);
 TextView r=new TextView(this); r.setText("اختر أداة:"); r.setTextColor(Color.LTGRAY); r.setTextSize(16); l.addView(r);
 Button a=new Button(this); a.setText("🔎 فحص localhost"); a.setOnClickListener(v->r.setText("localhost: 127.0.0.1\nفحص محلي آمن فقط.")); l.addView(a);
 Button n=new Button(this); n.setText("🌐 معلومات الشبكة"); n.setOnClickListener(v->r.setText("أداة معلومات الشبكة جاهزة. لا يتم إرسال البيانات للخارج.")); l.addView(n);
 Button p=new Button(this); p.setText("🔐 مولّد كلمة مرور"); p.setOnClickListener(v->{String c="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#"; SecureRandom x=new SecureRandom(); StringBuilder s=new StringBuilder(); for(int i=0;i<16;i++)s.append(c.charAt(x.nextInt(c.length()))); r.setText("كلمة مرور قوية:\n"+s);}); l.addView(p);
 Button d=new Button(this); d.setText("🧪 فحص DNS تعليمي"); d.setOnClickListener(v->r.setText("وضع التدريب: فحص DNS تعليمي محلي.")); l.addView(d); setContentView(l); }
}